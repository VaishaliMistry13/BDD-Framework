package com.homework;

public class ShortDataType {

    public static void main(String[] args) {

         long a = 125000000l;

        System.out.println(a);
    }
}

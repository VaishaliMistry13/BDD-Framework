package com.homework;

public class BooleanDataType {

    public static void main(String[] args) {

        boolean a = true;
        boolean b = false;

        if (a=b) {
            System.out.println("True");
        }
    }
}

package com.homework;

public class IntDataType {

    public static void main(String[] args) {

        int a = 21;

        System.out.println(a);
    }
}

package com.homework;

public class AgeLimit {

    public static void main(String[] args) {

        int Age = 17;

        if (Age<18) {
            System.out.println("Not Eligible To Vote");
        }else if (Age>18) {
            System.out.println("Eligible To Vote");
        }
    }
}

package com.homework;

public class DoubleDataType {

    public static void main(String[] args) {

        double num = 10.30;

        System.out.println(num);
    }
}

package com.homework;

public class LongDataType {

    public static void main(String[] args) {

        long a = 125000000l;

        System.out.println(a);
    }
}

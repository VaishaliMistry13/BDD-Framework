package com.homework;

public class ByteDataType {

    public static void main(String[] args) {

        byte a, b;

        a = 127;
        b = -128;

        System.out.println(a);
        System.out.println(b);
    }
}

package com.homework;

public class FloatDataType {

    public static void main(String[] args) {

        float num = 20.30f;

        System.out.println(num);
    }
}

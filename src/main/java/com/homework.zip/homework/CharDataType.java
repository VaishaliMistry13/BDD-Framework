package com.homework;

public class CharDataType {

    public static void main(String[] args) {

        char a = 'J';
        char b = 65;
        char c = 'K';

        System.out.println(b);
    }
}

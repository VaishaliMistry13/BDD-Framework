package com.homework;

public class PositiveNegative {

    public static void main(String[] args) {

        int nm1 = 18;
        int nm2 = -18;

        if (nm1>nm2) {
            System.out.println("18 Is Positive Number");

        }else if (nm1<nm2) {
            System.out.println("-18 Is Negative Number");

        }else {
            System.out.println("Zero Number");
        }
    }
}
